import React from 'react';

export default class Main extends React.Component{
  render(){
    return (<h2>H3we..</h2>)
  }
};
