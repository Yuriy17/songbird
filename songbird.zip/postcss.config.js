/* eslint import/no-extraneous-dependencies: ["error", {"devDependencies": true}] */
const autoprefixer = require('autoprefixer');

module.exports = {
  plugins: [autoprefixer],
};
